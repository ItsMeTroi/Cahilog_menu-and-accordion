export const questions = [
    {
        id: 1,
        question: "What is MLBB?",
        answer: "Its full name is Mobile Legends: Bang Bang, a Mobile MOBA Game.",
    },
    {
        id: 2,
        question: "What is Hero in the app icon of the game?",
        answer: "The hero in the app icon is named Miya, an easy-to-use Marksman in the game.",
    },
    {
        id: 3,
        question: "What are the roles in MLBB?",
        answer: "Pos1 = Jungle, Pos2 = Gold Lane, Pos3 = Exp Lane, Pos4 = Mid Lane, Pos5 = Roamer.",
    },
    {
        id: 4,
        question: "When was MLBB released?",
        answer: "MLBB was release on July 14, 2016.",
    },
    {
        id: 5,
        question: "Who is the hero in MLBB that was inspired from Attack of Titan?",
        answer: "The hero or heroine's name is Fanny, and she is one of the most difficult heroes to use in the game.",
    },
]